<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['apps']      = 'Free CMS Sekolahku';
$config['version']   = '2.1.0';
$config['webmaster'] = 'Anton Sofyan';
$config['email']     = '4ntonsofyan@gmail.com';
$config['website']   = 'http://www.sekolahku.web.id';